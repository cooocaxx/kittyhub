<template>
  <div class="vi-chart-container">
    <canvas ref="canvasRef" class="vi-canvas"></canvas>
    <div class="chart-overlay">
      <div class="axis-label x-label">电压 (V)</div>
      <div class="axis-label y-label">电流 (A)</div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, watch } from 'vue'

const props = defineProps({
  voltage: { type: Number, default: 0 },
  current: { type: Number, default: 0 }
})

const canvasRef = ref(null)
const dataPoints = ref([])
const animationId = ref(null)

// 历史数据点最大数量
const MAX_POINTS = 50

const drawChart = () => {
  const canvas = canvasRef.value
  if (!canvas) return

  const ctx = canvas.getContext('2d')
  const width = canvas.width = canvas.offsetWidth * 2
  const height = canvas.height = canvas.offsetHeight * 2

  // 清空画布
  ctx.clearRect(0, 0, width, height)

  // 图表区域边距
  const padding = { top: 20, right: 20, bottom: 30, left: 40 }
  const chartWidth = width - padding.left - padding.right
  const chartHeight = height - padding.top - padding.bottom

  // 绘制背景
  ctx.fillStyle = '#0d1117'
  ctx.fillRect(0, 0, width, height)

  // 绘制网格
  ctx.strokeStyle = '#21262d'
  ctx.lineWidth = 1

  // 垂直网格线 (X轴: 0, 1, 2, 3, 4, 5V)
  for (let v = 0; v <= 5; v++) {
    const x = padding.left + (v / 5) * chartWidth
    ctx.beginPath()
    ctx.moveTo(x, padding.top)
    ctx.lineTo(x, height - padding.bottom)
    ctx.stroke()
  }

  // 水平网格线 (Y轴: 0, 1, 2, 3, 4, 5A)
  for (let a = 0; a <= 5; a++) {
    const y = height - padding.bottom - (a / 5) * chartHeight
    ctx.beginPath()
    ctx.moveTo(padding.left, y)
    ctx.lineTo(width - padding.right, y)
    ctx.stroke()
  }

  // 绘制坐标轴
  ctx.strokeStyle = '#30363d'
  ctx.lineWidth = 2

  // X轴
  ctx.beginPath()
  ctx.moveTo(padding.left, height - padding.bottom)
  ctx.lineTo(width - padding.right, height - padding.bottom)
  ctx.stroke()

  // Y轴
  ctx.beginPath()
  ctx.moveTo(padding.left, padding.top)
  ctx.lineTo(padding.left, height - padding.bottom)
  ctx.stroke()

  // 绘制刻度标签
  ctx.fillStyle = '#8b949e'
  ctx.font = '20px JetBrains Mono, monospace'
  ctx.textAlign = 'center'

  // X轴刻度 (0-5V)
  for (let v = 0; v <= 5; v++) {
    const x = padding.left + (v / 5) * chartWidth
    ctx.fillText(v.toString(), x, height - padding.bottom + 25)
  }

  // Y轴刻度 (0-5A)
  ctx.textAlign = 'right'
  for (let a = 0; a <= 5; a++) {
    const y = height - padding.bottom - (a / 5) * chartHeight
    ctx.fillText(a.toString(), padding.left - 10, y + 5)
  }

  // 添加当前数据点到历史
  if (props.voltage > 0 || props.current > 0) {
    dataPoints.value.push({ v: props.voltage, a: props.current })
    if (dataPoints.value.length > MAX_POINTS) {
      dataPoints.value.shift()
    }
  }

  // 绘制历史数据点轨迹
  if (dataPoints.value.length > 1) {
    // 渐变轨迹线
    ctx.strokeStyle = '#3fb950'
    ctx.lineWidth = 2
    ctx.beginPath()

    dataPoints.value.forEach((point, index) => {
      const x = padding.left + (Math.min(point.v, 5.5) / 5.5) * chartWidth
      const y = height - padding.bottom - (Math.min(point.a, 5) / 5) * chartHeight

      if (index === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }
    })
    ctx.stroke()

    // 绘制轨迹点（淡出效果）
    dataPoints.value.forEach((point, index) => {
      const x = padding.left + (Math.min(point.v, 5.5) / 5.5) * chartWidth
      const y = height - padding.bottom - (Math.min(point.a, 5) / 5) * chartHeight
      const opacity = 0.3 + (index / dataPoints.value.length) * 0.7

      ctx.fillStyle = `rgba(63, 185, 80, ${opacity})`
      ctx.beginPath()
      ctx.arc(x, y, 3, 0, Math.PI * 2)
      ctx.fill()
    })
  }

  // 绘制当前点（高亮）
  if (props.voltage > 0 || props.current > 0) {
    const currentX = padding.left + (Math.min(props.voltage, 5.5) / 5.5) * chartWidth
    const currentY = height - padding.bottom - (Math.min(props.current, 5) / 5) * chartHeight

    // 发光效果
    const gradient = ctx.createRadialGradient(currentX, currentY, 0, currentX, currentY, 20)
    gradient.addColorStop(0, 'rgba(88, 166, 255, 0.8)')
    gradient.addColorStop(1, 'rgba(88, 166, 255, 0)')
    ctx.fillStyle = gradient
    ctx.beginPath()
    ctx.arc(currentX, currentY, 20, 0, Math.PI * 2)
    ctx.fill()

    // 当前点
    ctx.fillStyle = '#58a6ff'
    ctx.beginPath()
    ctx.arc(currentX, currentY, 6, 0, Math.PI * 2)
    ctx.fill()

    // 白色中心
    ctx.fillStyle = '#ffffff'
    ctx.beginPath()
    ctx.arc(currentX, currentY, 2, 0, Math.PI * 2)
    ctx.fill()
  }
}

onMounted(() => {
  drawChart()
  animationId.value = setInterval(drawChart, 100)
})

onUnmounted(() => {
  if (animationId.value) {
    clearInterval(animationId.value)
  }
})

// 监听数据变化
watch(() => [props.voltage, props.current], () => {
  // 数据更新会在下一帧绘制
})
</script>

<style scoped>
.vi-chart-container {
  position: relative;
  width: 100%;
  height: 140px;
  background: #0d1117;
  border-radius: 8px;
  overflow: hidden;
}

.vi-canvas {
  width: 100%;
  height: 100%;
}

.chart-overlay {
  position: absolute;
  inset: 0;
  pointer-events: none;
}

.axis-label {
  position: absolute;
  color: #8b949e;
  font-size: 0.7rem;
  font-weight: 500;
}

.x-label {
  bottom: 2px;
  left: 50%;
  transform: translateX(-50%);
}

.y-label {
  top: 50%;
  left: 2px;
  transform: translateY(-50%) rotate(-90deg);
  transform-origin: center center;
}
</style>
