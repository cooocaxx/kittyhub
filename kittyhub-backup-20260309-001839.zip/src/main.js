import { createApp } from 'vue'
import App from './App.vue'
import './assets/main.css'
import 'remixicon/fonts/remixicon.css' // 引入图标库
import { MotionPlugin } from '@vueuse/motion'

const app = createApp(App)
app.use(MotionPlugin)
app.mount('#app')
