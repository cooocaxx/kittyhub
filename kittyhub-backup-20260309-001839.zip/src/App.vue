<template>
  <div class="app-wrapper">
    <header class="header"
      v-motion
      :initial="{ opacity: 0, y: -30 }"
      :enter="{ opacity: 1, y: 0, transition: { duration: 600, ease: 'easeOut' } }">
      <div class="logo">🐱 KittyHub <span>Studio</span></div>

      <!-- 中间标签切换 -->
      <div class="header-tabs">
        <button :class="['header-tab', { active: activeTab === 'gallery' }]" @click="activeTab = 'gallery'">
          <span class="tab-icon">📁</span>
          <span>图库</span>
        </button>
        <button :class="['header-tab', { active: activeTab === 'power' }]" @click="activeTab = 'power'">
          <span class="tab-icon">⚡</span>
          <span>Power</span>
        </button>
      </div>

      <!-- 右侧操作区 -->
      <div class="header-actions">
        <button @click="isConnected ? disconnectDevice() : handleConnect()"
          :class="['status-badge', 'connectable', isConnected ? 'connected' : '']">
          <span class="status-dot"></span>
          <span class="status-text">{{ isConnected ? '已连接' : '点击连接' }}</span>
        </button>
        <button class="btn icon-btn" @click="showSettingsModal = true" :disabled="!isConnected" title="设备设置">⚙️</button>
      </div>
    </header>

    <main class="main-content">
      <!-- 图库标签页 -->
      <div v-show="activeTab === 'gallery'" class="card floating-card"
        v-motion
        :initial="{ opacity: 0, scale: 0.95, y: 30 }"
        :enter="{ opacity: 1, scale: 1, y: 0, transition: { duration: 500, ease: 'easeOut', delay: 150 } }">
        <!-- 投送区域 -->
        <div class="upload-section">
          <div class="upload-area-compact" @click="triggerFileInput" :class="{ 'disabled': !isConnected }">
            <span class="upload-icon-small">📤</span>
            <div class="upload-info">
              <span class="upload-title">投送图片或 GIF</span>
              <span class="upload-hint-small">支持 JPG/PNG/GIF</span>
            </div>
          </div>
          <input type="file" ref="fileInputRef" accept="image/*" class="hidden-input" @change="handleFileSelect">

          <p v-if="statusText" class="status-msg" :class="{ 'success': statusText.includes('成功') }">
            {{ statusText }}
          </p>

          <transition name="fade">
            <div v-if="isUploading" class="progress-wrapper">
              <div class="progress-info">
                <span>正在写入 Flash 存储...</span>
                <span class="progress-percent">{{ uploadProgress }}%</span>
              </div>
              <div class="progress-track">
                <div class="progress-fill" :style="{ width: uploadProgress + '%' }"></div>
              </div>
            </div>
          </transition>
        </div>

        <!-- 图库管理 -->
        <div class="card-header-flex">
          <h3>🗂️ 设备图库 ({{ deviceFiles.length }})</h3>
          <div class="header-actions-inner">
            <button class="btn icon-btn" @click="handleRotate" :disabled="!isConnected" title="旋转屏幕">🔄 旋转</button>
            <button class="btn icon-btn danger-btn" @click="handleWipe" :disabled="!isConnected" title="格式化图库">🗑️
              格式化</button>
            <button class="btn icon-btn" @click="refreshGallery" :disabled="!isConnected" title="刷新列表">🔃</button>
          </div>
        </div>

        <div v-if="isConnected && storageInfo.total > 0" class="storage-monitor">
          <div class="storage-track">
            <div class="storage-fill"
              :style="{ width: storageInfo.percent + '%', backgroundColor: storageInfo.percent > 85 ? '#da3633' : '#2ea043' }">
            </div>
          </div>
          <div class="storage-text">
            <span>总容量: {{ (storageInfo.total).toFixed(1) }} KB</span>
            <span :class="{ 'danger-text': storageInfo.percent > 85 }">剩余: {{ (storageInfo.free).toFixed(1) }} KB</span>
          </div>
        </div>

        <div class="file-list-container">
          <div v-if="!isConnected" class="empty-state">🔌 请先连接设备</div>
          <div v-else-if="deviceFiles.length === 0" class="empty-state">📦 图库空空如也</div>

          <div v-for="file in deviceFiles" :key="file.name" class="file-item">
            <div class="file-info">
              <span class="file-icon">{{ file.name.endsWith('.gif') ? '🎞️' : '🖼️' }}</span>
              <span class="file-name">{{ file.name.replace('/', '') }}</span>
              <span class="file-size">{{ (file.size / 1024).toFixed(1) }} KB</span>
            </div>
            <button class="delete-btn" @click="deleteFile(file.name)" title="删除文件">❌</button>
          </div>
        </div>
      </div>

      <!-- Power 标签页 -->
      <div v-show="activeTab === 'power'" class="card floating-card"
        v-motion
        :initial="{ opacity: 0, scale: 0.95, y: 30 }"
        :enter="{ opacity: 1, scale: 1, y: 0, transition: { duration: 500, ease: 'easeOut', delay: 150 } }">
        <h3 class="section-title">⚡ Power Monitor</h3>
        <div class="power-grid">
          <!-- USB1 -->
          <div class="usb-group">
            <div class="usb-header">
              <span class="usb-title">USB 1</span>
              <span class="usb-status" :class="{ active: isConnected }">{{ isConnected ? '在线' : '离线' }}</span>
            </div>
            <div class="power-content">
              <PowerChart :voltage="usb1Data.voltage" :current="usb1Data.current" />
              <div class="power-stats">
                <div class="stat-item">
                  <span class="stat-label">电压</span>
                  <span class="stat-value">{{ usb1Data.voltage.toFixed(2) }}V</span>
                </div>
                <div class="stat-item">
                  <span class="stat-label">电流</span>
                  <span class="stat-value">{{ (usb1Data.current * 1000).toFixed(0) }}mA</span>
                </div>
                <div class="stat-item power">
                  <span class="stat-label">功率</span>
                  <span class="stat-value">{{ (usb1Data.voltage * usb1Data.current * 1000).toFixed(0) }}mW</span>
                </div>
              </div>
            </div>
          </div>

          <!-- USB2 -->
          <div class="usb-group">
            <div class="usb-header">
              <span class="usb-title">USB 2</span>
              <span class="usb-status">离线</span>
            </div>
            <div class="power-content">
              <PowerChart :voltage="usb2Data.voltage" :current="usb2Data.current" />
              <div class="power-stats">
                <div class="stat-item">
                  <span class="stat-label">电压</span>
                  <span class="stat-value">{{ usb2Data.voltage.toFixed(2) }}V</span>
                </div>
                <div class="stat-item">
                  <span class="stat-label">电流</span>
                  <span class="stat-value">{{ (usb2Data.current * 1000).toFixed(0) }}mA</span>
                </div>
                <div class="stat-item power">
                  <span class="stat-label">功率</span>
                  <span class="stat-value">{{ (usb2Data.voltage * usb2Data.current * 1000).toFixed(0) }}mW</span>
                </div>
              </div>
            </div>
          </div>

          <!-- USB3 -->
          <div class="usb-group">
            <div class="usb-header">
              <span class="usb-title">USB 3</span>
              <span class="usb-status">离线</span>
            </div>
            <div class="power-content">
              <PowerChart :voltage="usb3Data.voltage" :current="usb3Data.current" />
              <div class="power-stats">
                <div class="stat-item">
                  <span class="stat-label">电压</span>
                  <span class="stat-value">{{ usb3Data.voltage.toFixed(2) }}V</span>
                </div>
                <div class="stat-item">
                  <span class="stat-label">电流</span>
                  <span class="stat-value">{{ (usb3Data.current * 1000).toFixed(0) }}mA</span>
                </div>
                <div class="stat-item power">
                  <span class="stat-label">功率</span>
                  <span class="stat-value">{{ (usb3Data.voltage * usb3Data.current * 1000).toFixed(0) }}mW</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Terminal (开发者模式) -->
      <div v-if="devMode" class="card floating-card terminal-card">
        <div class="terminal-header">
          <span>🚀 Terminal Output</span>
          <div class="window-controls">
            <i class="close"></i><i class="min"></i><i class="max"></i>
          </div>
        </div>
        <pre class="terminal-body" ref="terminalRef">{{ logText }}</pre>
      </div>
    </main>

    <!-- 设置模态框 -->
    <div v-if="showSettingsModal" class="modal-overlay"
      v-motion
      :initial="{ opacity: 0 }"
      :enter="{ opacity: 1, transition: { duration: 200 } }">
      <div class="modal-content settings-modal"
        v-motion
        :initial="{ opacity: 0, scale: 0.9, y: 20 }"
        :enter="{ opacity: 1, scale: 1, y: 0, transition: { duration: 300, ease: 'easeOut' } }">
        <div class="modal-header">
          <h3>⚙️ 设备系统设置</h3>
          <button class="close-btn" @click="showSettingsModal = false">×</button>
        </div>

        <div class="settings-form">
          <div class="form-group">
            <label>设备名称 (Device Name)</label>
            <input type="text" v-model="deviceConfig.name" maxlength="12" placeholder="给你的摆件起个名字">
          </div>

          <div class="form-group">
            <label>屏幕亮度 (Brightness: {{ deviceConfig.brightness }}%)</label>
            <input type="range" v-model.number="deviceConfig.brightness" min="5" max="100" step="5">
          </div>

          <div class="form-group">
            <label>画廊播放模式 (Play Mode)</label>
            <select v-model="deviceConfig.playMode">
              <option value="mixed">🔄 混合轮播 (GIF + JPG)</option>
              <option value="gif_only">🎞️ 仅播放动图 (GIF Only)</option>
              <option value="jpg_only">🖼️ 仅播放静态图 (JPG Only)</option>
            </select>
          </div>

          <div class="form-group">
            <label>自动轮播 (Auto Carousel)</label>
            <label class="toggle-wrapper">
              <div class="toggle-switch">
                <input type="checkbox" v-model="deviceConfig.autoRotate">
                <span class="slider"></span>
              </div>
              <span class="toggle-text">{{ deviceConfig.autoRotate ? '✅ 开启 (循环播放图库)' : '⏸️ 关闭 (锁定当前画面)' }}</span>
            </label>
          </div>

          <div class="form-group">
            <label>静态图停留时间 (Interval: {{ deviceConfig.interval }}s)</label>
            <input type="range" v-model.number="deviceConfig.interval" min="0" max="60" step="1">
            <span class="hint-text">注：GIF 动图会自动完整播放一遍，不受此时间限制。</span>
          </div>

          <div class="form-group">
            <label>开发者模式 (Developer Mode)</label>
            <label class="toggle-wrapper">
              <div class="toggle-switch">
                <input type="checkbox" v-model="devMode">
                <span class="slider"></span>
              </div>
              <span class="toggle-text">{{ devMode ? '✅ 开启 (显示调试终端)' : '⏸️ 关闭 (隐藏终端)' }}</span>
            </label>
          </div>
        </div>

        <div class="modal-footer">
          <button class="btn confirm-crop" @click="saveConfig">💾 写入硬件 Flash</button>
        </div>
      </div>
    </div>

    <div v-if="showCropModal" class="modal-overlay"
      v-motion
      :initial="{ opacity: 0 }"
      :enter="{ opacity: 1, transition: { duration: 200 } }">
      <div class="modal-content crop-modal"
        v-motion
        :initial="{ opacity: 0, scale: 0.9, y: 20 }"
        :enter="{ opacity: 1, scale: 1, y: 0, transition: { duration: 300, ease: 'easeOut' } }">
        <div class="modal-header">
          <h3>✨ 图片创作中心</h3>
          <p class="modal-hint">拖拽选框调整构图，使用下方工具栏精准控制</p>
        </div>

        <div class="crop-container">
          <Cropper ref="cropperRef" class="vue-cropper-instance" :src="cropUrl"
            :stencil-props="{ aspectRatio: getScreenRatio() }" :canvas="{ imageSmoothingQuality: 'high' }" />
        </div>

        <div class="crop-toolbar">
          <div class="tool-group">
            <button class="tool-btn" @click="cropZoom(2)">➕</button>
            <button class="tool-btn" @click="cropZoom(0.5)">➖</button>
          </div>
          <div class="tool-group">
            <button class="tool-btn" @click="cropRotate(-90)">🔄</button>
            <button class="tool-btn" @click="cropRotate(90)">↪️</button>
          </div>
        </div>

        <div class="modal-footer">
          <button class="btn cancel" @click="cancelCrop">取消</button>
          <button class="btn confirm-crop" @click="confirmCrop">✂️ 确认裁剪并发送</button>
        </div>
      </div>
    </div>
  </div>

  <div v-if="warningMessage" class="modal-overlay" style="z-index: 999;"
    v-motion
    :initial="{ opacity: 0 }"
    :enter="{ opacity: 1, transition: { duration: 200 } }">
    <div class="modal-content warning-modal"
      v-motion
      :initial="{ opacity: 0, scale: 0.9, y: 20 }"
      :enter="{ opacity: 1, scale: 1, y: 0, transition: { duration: 300, ease: 'easeOut' } }">
      <div class="warning-header">
        <h3>请求被拒绝</h3>
      </div>

      <div class="warning-body" v-html="warningMessage"></div>

      <div class="modal-footer">
        <button class="btn full-width danger" @click="warningMessage = ''">
          确认并返回
        </button>
      </div>
    </div>
  </div>


</template>

<script setup>
import { ref, watch, nextTick } from 'vue';
import { useSerial } from './composables/useSerial';

// 引入专为 Vue 3 开发的裁剪组件
import { Cropper } from 'vue-advanced-cropper';
import 'vue-advanced-cropper/dist/style.css';

// 引入功率图表组件
import PowerChart from './components/PowerChart.vue';


const { isConnected, logText, isUploading, uploadProgress, deviceFiles, deviceConfig, storageInfo, connectDevice, disconnectDevice, sendCommand } = useSerial();

const devMode = ref(false);
const activeTab = ref('gallery');
const showSettingsModal = ref(false);
const statusText = ref('');
const currentRotation = ref(1); // 0, 1, 2, 3 分别代表 0°, 90°, 180°, 270° 的旋转状态
const showCropModal = ref(false);
const cropUrl = ref('');

const fileInputRef = ref(null);
const terminalRef = ref(null);
const warningMessage = ref('');
const cropperRef = ref(null);

// USB 功率数据 (响应式)
const usb1Data = ref({ voltage: 0, current: 0 });
const usb2Data = ref({ voltage: 0, current: 0 });
const usb3Data = ref({ voltage: 0, current: 0 });

// 功率数据更新定时器
let powerUpdateTimer = null;

const setStatusTemp = (msg, time = 5000) => {
  statusText.value = msg;
  setTimeout(() => { statusText.value = ''; }, time);
};


// 保存配置并以 JSON 格式发送给设备
const saveConfig = async () => {
  if (!isConnected.value) return;
  const jsonString = JSON.stringify(deviceConfig.value);
  // 把 JSON 字符串转成二进制字节流发过去！
  const payload = new TextEncoder().encode(jsonString);

  await sendCommand("CONF", 0, payload); // CONF 指令代表 Configuration
  setStatusTemp("⚙️ 系统配置已更新并保存到设备！");
};


// ================= UI 与通信控制 =================
const handleConnect = async () => {
  if (!isConnected.value) {
    await connectDevice();
    await sendCommand("GETC"); // 获取配置 (GET Configuration)
    setTimeout(refreshGallery, 200);
  }
};
const handleRotate = async () => {
  if (!isConnected.value) return;
  currentRotation.value = (currentRotation.value + 1) % 4;
  await sendCommand("SROT", currentRotation.value);
};
const handleWipe = async () => {
  if (!isConnected.value) return;
  if (confirm("⚠️ 确认要永久格式化设备图库吗？")) {
    await sendCommand("WIPE", 0);
    setTimeout(refreshGallery, 100);
    setStatusTemp("设备存储已格式化！", 3000);
  }
};
const triggerFileInput = () => {
  if (!isConnected.value) return alert("请先连接设备！");
  fileInputRef.value.click();
};
const getScreenRatio = () => (currentRotation.value === 1 || currentRotation.value === 3) ? 320 / 170 : 170 / 320;

// ================= 文件入口 =================
const handleFileSelect = async (e) => {
  const file = e.target.files[0];
  if (!file) return;

  if (file.type === "image/gif") {
    const arrayBuffer = await file.arrayBuffer();
    const view = new DataView(arrayBuffer);
    const gifWidth = view.getUint16(6, true);
    const gifHeight = view.getUint16(8, true);

    if (gifWidth > 320 || gifHeight > 320) {
      if (confirm(`🚫 动图尺寸过大 (${gifWidth}x${gifHeight})！\n💡 提取它的第一帧作为静态图裁剪？`)) {
        cropUrl.value = URL.createObjectURL(file);
        showCropModal.value = true;
      }
    } else {
      const fileKB = file.size / 1024;
      if (!checkSpaceAndAlert(fileKB)) {
        if (fileInputRef.value) fileInputRef.value.value = "";
        return; // 空间不足，直接终止！
      }

      statusText.value = "🚀 正在发送 GIF...";
      await sendCommand("ANIM", 0, new Uint8Array(arrayBuffer));
      setStatusTemp("🎉 GIF 发送成功！");

      setTimeout(refreshGallery, 200);
    }
  } else {
    cropUrl.value = URL.createObjectURL(file);
    showCropModal.value = true;
  }
  if (fileInputRef.value) fileInputRef.value.value = "";
};

// ================= Vue 原生工具栏控制 =================
const cropZoom = (factor) => cropperRef.value?.zoom(factor);
const cropRotate = (angle) => cropperRef.value?.rotate(angle);

// ================= 极度安全的下发引擎 =================
const confirmCrop = () => {
  if (!cropperRef.value) return alert("裁剪器未就绪！");

  statusText.value = "🎨 正在转码处理...";

  // 1. 获取原图裁剪区域的画布
  const { canvas } = cropperRef.value.getResult();
  if (!canvas) return alert("获取画布失败！");

  // 2. 强制二次重绘！
  // 为了保证下发给 RP2040 的尺寸【绝对精准】是 320x170 或 170x320，
  // 我们建立一个终极输出画布，将裁剪结果等比画上去，彻底绝杀因原图过大导致的 OOM 死机！
  const { w, h } = (currentRotation.value === 1 || currentRotation.value === 3) ? { w: 320, h: 170 } : { w: 170, h: 320 };
  const finalCanvas = document.createElement('canvas');
  finalCanvas.width = w;
  finalCanvas.height = h;
  const ctx = finalCanvas.getContext('2d');

  // 填黑底防止透明 PNG 报错
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, w, h);
  // 高质量重采样
  ctx.drawImage(canvas, 0, 0, w, h);

  // 3. 转码下发
  finalCanvas.toBlob(async (blob) => {
    if (blob) {

      const blobKB = blob.size / 1024;
      if (!checkSpaceAndAlert(blobKB)) {
        return; // 拦截下发，此时裁剪框不会关，用户点完警告后可以点取消
      }

      const payload = new Uint8Array(await blob.arrayBuffer());
      cancelCrop(); // 关闭弹窗
      await sendCommand("JPEG", 0, payload);
      setStatusTemp("🖼️ 静态图片下发成功！");
      setTimeout(refreshGallery, 200);
    }
  }, 'image/jpeg', 0.95);
};

const cancelCrop = () => {
  showCropModal.value = false;
  if (cropUrl.value) {
    URL.revokeObjectURL(cropUrl.value);
    cropUrl.value = '';
  }
};

watch(logText, async () => {
  await nextTick();
  if (terminalRef.value) terminalRef.value.scrollTop = terminalRef.value.scrollHeight;
});

// ================= Power 数据更新 =================
const updatePowerData = () => {
  // USB1 模拟数据 (电压 0-5.5V, 电流 0-5A)
  usb1Data.value = {
    voltage: 3.2 + Math.random() * 0.3,
    current: 0.08 + Math.random() * 0.04
  };
  // USB2, USB3 保持为 0 (离线)
};

watch(activeTab, (newTab) => {
  if (newTab === 'power') {
    powerUpdateTimer = setInterval(updatePowerData, 100);
  } else if (powerUpdateTimer) {
    clearInterval(powerUpdateTimer);
    powerUpdateTimer = null;
  }
});

// ================= 图库管理逻辑 =================
const refreshGallery = async () => {
  if (!isConnected.value) return;
  await sendCommand("LIST");
  setStatusTemp("🔄 已请求最新图库列表");
};

const deleteFile = async (fileName) => {
  if (!isConnected.value) return;
  if (confirm(`确定要从设备中删除 [ ${fileName} ] 吗？`)) {
    // 将字符串转为 Uint8Array 发过去
    const nameBytes = new TextEncoder().encode(fileName);
    await sendCommand("DELF", 0, nameBytes);

    // 删完后自动重新拉取列表！
    setTimeout(refreshGallery, 500);
  }
};
// ================= 新增：空间不足警告状态 =================
const checkSpaceAndAlert = (fileSizeKB) => {
  // 如果设备还没传回总容量（可能是刚连上还没刷新），默认放行防误杀
  if (storageInfo.value.total === 0) return true;

  if (fileSizeKB > storageInfo.value.free) {
    warningMessage.value = `
      <div style="font-size: 1.1rem; margin-bottom: 1rem;">设备剩余空间严重不足！</div>
      上传需要: <span class="highlight-text">${fileSizeKB.toFixed(1)} KB</span><br>
      当前剩余: <span style="color: #2ea043; font-weight: bold;">${storageInfo.value.free.toFixed(1)} KB</span><br><br>
      <div style="font-size: 0.9rem; color: #8b949e;">👉 请先到左侧【设备图库】删除一些旧文件。</div>
    `;
    return false; // 拦截！
  }
  return true; // 放行！
};

</script>

<style scoped>
/* ================= 现代悬浮卡片布局 ================= */
.app-wrapper {
  min-height: 100vh;
  background: linear-gradient(135deg, #0a0d12 0%, #0d1117 50%, #090c10 100%);
  color: #c9d1d9;
  font-family: 'Segoe UI', system-ui, sans-serif;
  display: flex;
  flex-direction: column;
}

/* ================= 顶部导航栏 ================= */
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.75rem 1.5rem;
  margin: 1rem 1.5rem 0;
  background: rgba(22, 27, 34, 0.85);
  backdrop-filter: blur(20px);
  border-radius: 20px;
  border: 1px solid rgba(48, 54, 61, 0.6);
  box-shadow:
    0 8px 32px rgba(0, 0, 0, 0.3),
    0 0 0 1px rgba(255, 255, 255, 0.03) inset;
}

.logo {
  font-size: 1.3rem;
  font-weight: 800;
  color: #f0f6fc;
  display: flex;
  align-items: center;
  gap: 0.25rem;
}

.logo span {
  color: #58a6ff;
  font-weight: 400;
}

/* 中间标签切换 */
.header-tabs {
  display: flex;
  gap: 0.5rem;
  background: #21262d;
  padding: 4px;
  border-radius: 12px;
  border: 1px solid #30363d;
}

.header-tab {
  display: flex;
  align-items: center;
  gap: 0.4rem;
  padding: 0.5rem 1.25rem;
  border: none;
  background: transparent;
  color: #8b949e;
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.9rem;
  font-weight: 500;
  transition: all 0.2s ease;
}

.header-tab:hover {
  color: #c9d1d9;
  background: #30363d;
}

.header-tab.active {
  background: #388bfd;
  color: white;
  box-shadow: 0 2px 8px rgba(56, 139, 253, 0.3);
}

/* 标签页切换动画 */
.card.floating-card {
  transition: opacity 0.3s ease;
}

.header-tab .tab-icon {
  font-size: 1rem;
}

/* 右侧操作区 */
.header-actions {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.status-badge {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  background: #21262d;
  border-radius: 20px;
  font-size: 0.85rem;
  color: #8b949e;
  border: 1px solid #30363d;
  cursor: pointer;
  transition: all 0.2s;
}

.status-badge.connectable:hover {
  background: #30363d;
  border-color: #58a6ff;
}

.status-badge .status-dot {
  width: 8px;
  height: 8px;
  background: #ff6a00;
  border-radius: 50%;
  box-shadow: 0 0 6px #ff6a00;
}

.status-badge.connected {
  color: #3fb950;
  border-color: #238636;
  background: rgba(46, 160, 67, 0.15);
}

.status-badge.connected:hover {
  background: rgba(218, 54, 51, 0.15);
  border-color: #da3633;
  color: #ff7b72;
}

.status-badge.connected .status-dot {
  background: #3fb950;
  box-shadow: 0 0 8px #3fb950;
}

.status-badge .status-text {
  font-weight: 500;
}

/* ================= 主内容区 ================= */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  gap: 1.5rem;
}

/* 悬浮卡片效果 */
.floating-card {
  background: rgba(22, 27, 34, 0.9);
  backdrop-filter: blur(20px);
  border-radius: 36px;
  padding: 3.5rem 5rem;
  border: 1px solid rgba(48, 54, 61, 0.6);
  box-shadow:
    0 40px 80px rgba(0, 0, 0, 0.5),
    0 0 0 1px rgba(255, 255, 255, 0.05) inset,
    0 0 120px rgba(56, 139, 253, 0.12);
  width: 100%;
  max-width: 1400px;
  min-height: 850px;
  transition: all 0.3s ease;
}

.floating-card:hover {
  box-shadow:
    0 30px 60px rgba(0, 0, 0, 0.6),
    0 0 0 1px rgba(255, 255, 255, 0.08) inset,
    0 0 100px rgba(56, 139, 253, 0.12);
  border-color: rgba(56, 139, 253, 0.3);
  transform: translateY(-2px);
}

/* ================= 卡片样式 ================= */
.card {
  background: rgba(22, 27, 34, 0.85);
  backdrop-filter: blur(16px);
  border-radius: 16px;
  padding: 1.5rem;
  border: 1px solid rgba(48, 54, 61, 0.6);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
}

h3 {
  margin-top: 0;
  color: #f0f6fc;
  font-size: 1rem;
  font-weight: 600;
  margin-bottom: 1rem;
}

.section-title {
  color: #f0f6fc;
  font-size: 1rem;
  text-transform: none;
  letter-spacing: 0;
  margin-bottom: 1rem;
}

.btn {
  padding: 0.5rem 1rem;
  border-radius: 8px;
  border: 1px solid transparent;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  font-size: 0.85rem;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}

.btn:hover:not(:disabled) {
  transform: translateY(-1px);
  filter: brightness(1.1);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
}

.btn:active:not(:disabled) {
  transform: translateY(0);
}

.btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  filter: grayscale(0.5);
  transform: none !important;
  box-shadow: none !important;
}

.icon-btn {
  padding: 0.4rem 0.6rem;
  background: rgba(33, 38, 45, 0.8);
  border-radius: 8px;
  border: 1px solid #30363d;
  color: #c9d1d9;
  font-size: 0.85rem;
}

.icon-btn:hover:not(:disabled) {
  background: #30363d;
  border-color: #58a6ff;
}

.danger-btn {
  background: rgba(33, 38, 45, 0.8);
  border-color: #30363d;
}

.danger-btn:hover:not(:disabled) {
  background: rgba(218, 54, 51, 0.15);
  border-color: #da3633;
  color: #ff7b72;
}

.danger {
  background: #da3633;
  color: white;
}

.cancel {
  background: #30363d;
  color: #c9d1d9;
}

.confirm-crop {
  background: linear-gradient(135deg, #db61a2 0%, #c45a8e 100%);
  color: white;
  font-size: 1rem;
  padding: 0.8rem 2rem;
  border: none;
}

.hidden-input {
  display: none;
}

.status-msg {
  margin-top: 1rem;
  color: #e3b341;
  font-size: 0.9rem;
  text-align: center;
  font-weight: 500;
}

.status-msg.success {
  color: #3fb950;
}

/* ================= 紧凑型投送区域 ================= */
.upload-section {
  margin-bottom: 1.5rem;
  padding-bottom: 1.5rem;
  border-bottom: 1px solid rgba(48, 54, 61, 0.5);
}

.upload-area-compact {
  display: flex;
  align-items: center;
  gap: 1rem;
  background: linear-gradient(135deg, rgba(33, 38, 45, 0.6) 0%, rgba(22, 27, 34, 0.6) 100%);
  border: 2px dashed #30363d;
  border-radius: 12px;
  padding: 1rem 1.5rem;
  cursor: pointer;
  transition: all 0.3s;
}

.upload-area-compact:hover:not(.disabled) {
  border-color: #58a6ff;
  background: linear-gradient(135deg, rgba(38, 44, 54, 0.8) 0%, rgba(26, 31, 37, 0.8) 100%);
  transform: translateY(-2px);
}

.upload-area-compact.disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.upload-icon-small {
  font-size: 2rem;
  opacity: 0.9;
}

.upload-info {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}

.upload-title {
  color: #58a6ff;
  font-weight: 600;
  font-size: 1rem;
}

.upload-hint-small {
  color: #8b949e;
  font-size: 0.8rem;
}

.upload-section .status-msg {
  margin-top: 0.75rem;
  margin-bottom: 0;
}

.upload-section .progress-wrapper {
  margin-top: 0.75rem;
}

/* ================= 终端样式 ================= */
.terminal-card {
  padding: 0;
  display: flex;
  flex-direction: column;
  height: 400px;
  overflow: hidden;
}

.terminal-header {
  background: rgba(33, 38, 45, 0.8);
  padding: 0.6rem 1rem;
  border-radius: 20px 20px 0 0;
  border-bottom: 1px solid rgba(48, 54, 61, 0.5);
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.8rem;
  color: #8b949e;
}

.window-controls i {
  display: inline-block;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: #da3633;
  margin-left: 8px;
}

.window-controls i.min {
  background: #d29922;
}

.window-controls i.max {
  background: #2ea043;
}

.terminal-body {
  background: rgba(13, 17, 23, 0.8);
  color: #7ee787;
  flex: 1;
  margin: 0;
  padding: 1rem;
  border-radius: 0 0 20px 20px;
  font-family: monospace;
  font-size: 0.85rem;
  line-height: 1.6;
  overflow-y: auto;
  /* 内容超出时显示滚动条 */
  min-height: 0;
  /* 核心修复 2：极其关键！告诉 Flexbox 允许内容压缩，从而触发滚动条！ */
  white-space: pre-wrap;
  word-break: break-all;

  /* 美化一下滚动条，让它更有极客感 */
  scrollbar-width: thin;
  scrollbar-color: #30363d #0d1117;
}

/* Chrome/Edge 专属滚动条美化 */
.terminal-body::-webkit-scrollbar {
  width: 8px;
}

.terminal-body::-webkit-scrollbar-track {
  background: #0d1117;
  border-radius: 0 0 12px 0;
}

.terminal-body::-webkit-scrollbar-thumb {
  background: #30363d;
  border-radius: 4px;
}

.terminal-body::-webkit-scrollbar-thumb:hover {
  background: #58a6ff;
}

/* ================= 纯粹的弹窗样式 ================= */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.85);
  backdrop-filter: blur(8px);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 100;
}

.crop-modal {
  background: #161b22;
  padding: 1.5rem;
  border-radius: 16px;
  width: 90vw;
  max-width: 900px;
  border: 1px solid #30363d;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6);
}

.modal-header h3 {
  color: #f0f6fc;
  font-size: 1.2rem;
  margin-bottom: 0.5rem;
  letter-spacing: 0;
  text-transform: none;
}

.modal-hint {
  color: #8b949e;
  font-size: 0.9rem;
  margin: 0 0 1.5rem 0;
}

/* vue-advanced-cropper 容器要求 */
.crop-container {
  width: 100%;
  height: 55vh;
  background: #0d1117;
  border-radius: 8px;
  overflow: hidden;
  border: 1px solid #30363d;
}

.vue-cropper-instance {
  height: 100%;
  width: 100%;
}

.crop-toolbar {
  display: flex;
  justify-content: center;
  gap: 1.5rem;
  margin: 1.5rem 0;
  background: #21262d;
  padding: 0.8rem;
  border-radius: 12px;
  border: 1px solid #30363d;
}

.tool-group {
  display: flex;
  gap: 0.5rem;
}

.tool-btn {
  background: #30363d;
  color: #c9d1d9;
  border: none;
  width: 40px;
  height: 40px;
  border-radius: 8px;
  font-size: 1.2rem;
  cursor: pointer;
  transition: 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
}

.tool-btn:hover {
  background: #58a6ff;
  color: #0f172a;
  transform: scale(1.1);
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
  border-top: 1px solid #30363d;
  padding-top: 1.5rem;
}

/* ================= 极客风矩形进度条样式 ================= */
.progress-wrapper {
  margin-top: 1.5rem;
  background: #21262d;
  padding: 1rem;
  border-radius: 8px;
  border: 1px solid #30363d;
}

.progress-info {
  display: flex;
  justify-content: space-between;
  font-size: 0.85rem;
  color: #8b949e;
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.progress-percent {
  color: #58a6ff;
  font-family: 'JetBrains Mono', monospace;
}

/* 轨道背景 */
.progress-track {
  width: 100%;
  height: 8px;
  background: #0d1117;
  border-radius: 4px;
  overflow: hidden;
  box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.5);
}

/* 填充条 - 带有丝滑的过渡动画和科技蓝高亮 */
.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #38bdf8, #2563eb);
  border-radius: 4px;
  transition: width 0.1s ease-out;
  /* 让进度条涨起来极其丝滑 */
  box-shadow: 0 0 10px rgba(56, 189, 248, 0.5);
}

/* ================= 设备图库 UI ================= */
.card-header-flex {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
}

.card-header-flex h3 {
  margin: 0;
  color: #f0f6fc;
  font-size: 1rem;
}

.header-actions-inner {
  display: flex;
  gap: 0.5rem;
}

.full-width {
  width: 100%;
}

/* Power Monitor 样式 */
.section-title {
  color: #f0f6fc;
  font-size: 1rem;
  text-transform: none;
  letter-spacing: 0;
  margin-bottom: 1rem;
}

.power-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1rem;
}

.usb-group {
  background: rgba(13, 17, 23, 0.6);
  border-radius: 12px;
  padding: 0.75rem;
  border: 1px solid rgba(48, 54, 61, 0.5);
  transition: all 0.2s ease;
}

.usb-group:hover {
  border-color: rgba(56, 139, 253, 0.3);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
}

.usb-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
  padding-bottom: 0.75rem;
  border-bottom: 1px solid #30363d;
}

.usb-title {
  color: #f0f6fc;
  font-size: 0.95rem;
  font-weight: 600;
}

.usb-status {
  font-size: 0.75rem;
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  background: #30363d;
  color: #8b949e;
}

.usb-status.active {
  background: rgba(46, 160, 67, 0.2);
  color: #3fb950;
}

.power-content {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.power-stats {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 0.5rem;
}

.stat-item {
  background: #161b22;
  border-radius: 8px;
  padding: 0.6rem 0.8rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.25rem;
}

.stat-label {
  color: #8b949e;
  font-size: 0.7rem;
}

.stat-value {
  color: #58a6ff;
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.9rem;
  font-weight: bold;
}

.stat-item.power {
  background: linear-gradient(135deg, #1a2332 0%, #0d1117 100%);
  border: 1px solid #30363d;
}

.stat-item.power .stat-label {
  color: #f0883e;
}

.stat-item.power .stat-value {
  color: #f0883e;
  font-size: 1rem;
}

@media (max-width: 768px) {
  .header {
    margin: 0.75rem 1rem 0;
    padding: 0.6rem 1rem;
    flex-wrap: wrap;
    gap: 0.75rem;
  }

  .header-tabs {
    order: 3;
    width: 100%;
    justify-content: center;
  }

  .power-grid {
    grid-template-columns: repeat(2, 1fr);
  }

  .floating-card {
    padding: 1.25rem;
    border-radius: 16px;
  }
}

@media (max-width: 550px) {
  .power-grid {
    grid-template-columns: 1fr;
  }

  .power-stats {
    grid-template-columns: 1fr;
  }

  .header-actions {
    gap: 0.5rem;
  }

  .status-badge {
    display: none;
  }
}

.file-list-container {
  background: rgba(13, 17, 23, 0.5);
  border-radius: 12px;
  border: 1px solid rgba(48, 54, 61, 0.5);
  min-height: 120px;
  max-height: 250px;
  overflow-y: auto;
  padding: 0.5rem;
  scrollbar-width: thin;
  scrollbar-color: #30363d transparent;
}

.empty-state {
  text-align: center;
  color: #8b949e;
  padding: 2rem 0;
  font-size: 0.9rem;
}

.file-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.6rem 0.8rem;
  border-radius: 6px;
  transition: background 0.2s;
}

.file-item:hover {
  background: #161b22;
}

.file-info {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  overflow: hidden;
}

.file-icon {
  font-size: 1.1rem;
}

.file-name {
  color: #c9d1d9;
  font-size: 0.9rem;
  font-family: monospace;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 140px;
}

.file-size {
  color: #8b949e;
  font-size: 0.75rem;
  background: #21262d;
  padding: 2px 6px;
  border-radius: 4px;
}

.delete-btn {
  background: transparent;
  border: none;
  cursor: pointer;
  opacity: 0.5;
  transition: 0.2s;
  font-size: 0.9rem;
}

.file-item:hover .delete-btn {
  opacity: 1;
}

.delete-btn:hover {
  transform: scale(1.2);
  filter: drop-shadow(0 0 4px #da3633);
}


/* ================= 系统设置模态框样式 ================= */
.settings-modal {
  width: 90vw;
  max-width: 480px;
  border-radius: 20px;
  /* 设置面板不需要像裁剪框那么宽，紧凑点更精致 */
  padding: 0;
  /* 移除通用 padding，重新精细控制 */
  overflow: hidden;
}

.settings-modal .modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem 2rem;
  background: #21262d;
  border-bottom: 1px solid #30363d;
}

.settings-modal h3 {
  margin: 0;
  color: #f0f6fc;
  font-size: 1.25rem;
  text-transform: none;
}

/* 优雅的关闭按钮 */
.close-btn {
  background: transparent;
  border: none;
  color: #8b949e;
  font-size: 2rem;
  line-height: 1;
  cursor: pointer;
  transition: color 0.2s, transform 0.2s;
  padding: 0;
}

.close-btn:hover {
  color: #da3633;
  transform: scale(1.1);
}

.settings-form {
  padding: 2rem;
  display: flex;
  background: #21262d;
  flex-direction: column;
  gap: 1.5rem;
}

.form-group {
  display: flex;
  flex-direction: column;
  text-align: left;
}

.form-group label {
  color: #c9d1d9;
  font-size: 0.95rem;
  margin-bottom: 0.6rem;
  font-weight: 500;
}

/* 深度定制输入框和下拉菜单 */
.form-group input[type="text"],
.form-group select {
  background: #0d1117;
  border: 1px solid #30363d;
  color: #58a6ff;
  font-weight: bold;
  padding: 0.8rem 1rem;
  border-radius: 8px;
  font-size: 1rem;
  outline: none;
  transition: all 0.2s;
  appearance: none;
  /* 清除原生下拉箭头 */
}

/* 如果是 select，我们手写一个极客风的下拉箭头 */
.form-group select {
  background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%238b949e' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
  background-repeat: no-repeat;
  background-position: right 1rem center;
  background-size: 1em;
  cursor: pointer;
}

.form-group input[type="text"]:focus,
.form-group select:focus {
  border-color: #58a6ff;
  box-shadow: 0 0 0 3px rgba(88, 166, 255, 0.2);
}

/* 极具科技感的自定义滑动条 (Range Slider) */
.form-group input[type="range"] {
  -webkit-appearance: none;
  width: 100%;
  height: 6px;
  background: #30363d;
  border-radius: 3px;
  outline: none;
  margin: 10px 0;
}

.form-group input[type="range"]::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: #58a6ff;
  cursor: pointer;
  transition: 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 0 10px rgba(88, 166, 255, 0.5);
}

.form-group input[type="range"]::-webkit-slider-thumb:hover {
  transform: scale(1.3);
  background: #79c0ff;
}

.hint-text {
  color: #8b949e;
  font-size: 0.8rem;
  margin-top: 0.6rem;
}

.settings-modal .modal-footer {
  padding: 1.5rem 2rem;
  background: #161b22;
  border-top: 1px solid #30363d;
  display: flex;
  justify-content: center;
  /* 按钮居中，更有仪式感 */
}


/* ================= 赛博朋克风 Toggle 开关 ================= */
.toggle-wrapper {
  display: flex;
  align-items: center;
  gap: 1rem;
  cursor: pointer;
}

.toggle-switch {
  position: relative;
  width: 50px;
  height: 26px;
  flex-shrink: 0;
}

.toggle-switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #30363d;
  border-radius: 34px;
  transition: .3s cubic-bezier(0.4, 0, 0.2, 1);
  border: 1px solid #161b22;
}

.slider:before {
  position: absolute;
  content: "";
  height: 18px;
  width: 18px;
  left: 3px;
  bottom: 3px;
  background-color: #8b949e;
  border-radius: 50%;
  transition: .3s cubic-bezier(0.4, 0, 0.2, 1);
}

.toggle-switch input:checked+.slider {
  background-color: #2ea043;
  border-color: #2ea043;
  box-shadow: 0 0 12px rgba(46, 160, 67, 0.4);
}

.toggle-switch input:checked+.slider:before {
  transform: translateX(24px);
  background-color: #fff;
}

.toggle-text {
  color: #c9d1d9;
  font-weight: bold;
  font-size: 0.95rem;
}


/* ================= 存储空间进度条 UI ================= */
.storage-monitor {
  margin-bottom: 1rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid rgba(48, 54, 61, 0.5);
}

.storage-track {
  width: 100%;
  height: 6px;
  background: rgba(13, 17, 23, 0.6);
  border-radius: 3px;
  overflow: hidden;
  margin-bottom: 0.5rem;
}

.storage-fill {
  height: 100%;
  border-radius: 3px;
  transition: width 0.4s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.3s;
}

.storage-text {
  display: flex;
  justify-content: space-between;
  font-size: 0.75rem;
  color: #8b949e;
  font-family: 'JetBrains Mono', monospace;
  font-weight: 500;
}

.danger-text {
  color: #da3633 !important;
  font-weight: bold;
}

/* ================= 赛博朋克风：警告弹窗 ================= */
.warning-modal {
  width: 90vw;
  max-width: 400px;
  background: #161b22;
  /* 回归主板的深灰色 */
  padding: 0;
  border: 1px solid #30363d;
  /* 核心视觉：顶部一根硬朗的血红色警告线，加上隐约的红色环境光 */
  border-top: 4px solid #da3633;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.8), 0 0 20px rgba(218, 54, 51, 0.15);
  border-radius: 12px;
  overflow: hidden;
}

.warning-header {
  background: #21262d;
  padding: 1rem;
  border-bottom: 1px solid #30363d;
  text-align: center;
}

.warning-header h3 {
  color: #ff7b72;
  margin: 0;
  font-size: 1.1rem;
  letter-spacing: 2px;
}

.warning-body {
  padding: 2rem 1.5rem;
  background: #0d1117;
  /* 内容区用更深的纯黑，凸显发光文字 */
  color: #c9d1d9;
  font-size: 0.95rem;
  line-height: 1.8;
  text-align: center;
}

/* 拦截信息中的动态高亮数字，做成代码块样式的警示标签 */
:deep(.highlight-text) {
  color: #ff7b72;
  font-weight: bold;
  font-family: 'JetBrains Mono', monospace;
  background: rgba(218, 54, 51, 0.1);
  padding: 2px 8px;
  border-radius: 4px;
  border: 1px solid rgba(218, 54, 51, 0.3);
}

.warning-modal .modal-footer {
  background: #161b22;
  padding: 1.2rem;
  border-top: 1px solid #30363d;
}
</style>
